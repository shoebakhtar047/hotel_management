import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Vector;

public class HotelReservationSystemSwing {
    private static final String url = "jdbc:mysql://localhost:3306/hotel_db";
    private static final String username = "root";
    private static final String password = "password";
    private static Connection connection;

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);

            SwingUtilities.invokeLater(() -> {
                new HotelReservationSystemSwing().createGUI();
            });
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void createGUI() {
        JFrame frame = new JFrame("Hotel Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new BorderLayout());

        // Panel to hold buttons and user interaction components
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1));

        // Add options
        JButton reserveButton = new JButton("Reserve a Room");
        JButton viewButton = new JButton("View Reservations");
        JButton updateButton = new JButton("Update Reservation");
        JButton deleteButton = new JButton("Delete Reservation");
        JButton getRoomButton = new JButton("Get Room Number");
        JButton exitButton = new JButton("Exit");

        panel.add(reserveButton);
        panel.add(viewButton);
        panel.add(updateButton);
        panel.add(deleteButton);
        panel.add(getRoomButton);
        panel.add(exitButton);

        frame.add(panel, BorderLayout.CENTER);

        // Set up button actions
        reserveButton.addActionListener(e -> showReserveDialog());
        viewButton.addActionListener(e -> viewReservations());
        updateButton.addActionListener(e -> showUpdateDialog());
        deleteButton.addActionListener(e -> showDeleteDialog());
        getRoomButton.addActionListener(e -> showGetRoomDialog());
        exitButton.addActionListener(e -> exitSystem());

        frame.setVisible(true);
    }

    // Dialog to reserve a room
    private void showReserveDialog() {
        JTextField guestNameField = new JTextField(15);
        JTextField roomNumberField = new JTextField(5);
        JTextField contactNumberField = new JTextField(15);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 2));
        panel.add(new JLabel("Guest Name:"));
        panel.add(guestNameField);
        panel.add(new JLabel("Room Number:"));
        panel.add(roomNumberField);
        panel.add(new JLabel("Contact Number:"));
        panel.add(contactNumberField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Reserve Room", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String guestName = guestNameField.getText();
            int roomNumber = Integer.parseInt(roomNumberField.getText());
            String contactNumber = contactNumberField.getText();

            reserveRoom(guestName, roomNumber, contactNumber);
        }
    }

    // Dialog to update a reservation
    private void showUpdateDialog() {
        JTextField reservationIdField = new JTextField(5);
        JTextField newGuestNameField = new JTextField(15);
        JTextField newRoomNumberField = new JTextField(5);
        JTextField newContactNumberField = new JTextField(15);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 2));
        panel.add(new JLabel("Reservation ID:"));
        panel.add(reservationIdField);
        panel.add(new JLabel("New Guest Name:"));
        panel.add(newGuestNameField);
        panel.add(new JLabel("New Room Number:"));
        panel.add(newRoomNumberField);
        panel.add(new JLabel("New Contact Number:"));
        panel.add(newContactNumberField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Update Reservation", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            int reservationId = Integer.parseInt(reservationIdField.getText());
            String newGuestName = newGuestNameField.getText();
            int newRoomNumber = Integer.parseInt(newRoomNumberField.getText());
            String newContactNumber = newContactNumberField.getText();

            updateReservation(reservationId, newGuestName, newRoomNumber, newContactNumber);
        }
    }

    // Dialog to delete a reservation
    private void showDeleteDialog() {
        JTextField reservationIdField = new JTextField(5);
        JPanel panel = new JPanel();
        panel.add(new JLabel("Reservation ID:"));
        panel.add(reservationIdField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Delete Reservation", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            int reservationId = Integer.parseInt(reservationIdField.getText());
            deleteReservation(reservationId);
        }
    }

    // Dialog to get room number by reservation ID and guest name
    private void showGetRoomDialog() {
        JTextField reservationIdField = new JTextField(5);
        JTextField guestNameField = new JTextField(15);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));
        panel.add(new JLabel("Reservation ID:"));
        panel.add(reservationIdField);
        panel.add(new JLabel("Guest Name:"));
        panel.add(guestNameField);

        int option = JOptionPane.showConfirmDialog(null, panel, "Get Room Number", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            int reservationId = Integer.parseInt(reservationIdField.getText());
            String guestName = guestNameField.getText();

            getRoomNumber(reservationId, guestName);
        }
    }

    private void reserveRoom(String guestName, int roomNumber, String contactNumber) {
        String sql = "INSERT INTO reservations (guest_name, room_number, contact_number) " +
                "VALUES (?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, guestName);
            stmt.setInt(2, roomNumber);
            stmt.setString(3, contactNumber);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Reservation successful!");
            } else {
                JOptionPane.showMessageDialog(null, "Reservation failed.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void viewReservations() {
        String sql = "SELECT reservation_id, guest_name, room_number, contact_number, reservation_date FROM reservations";

        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            Vector<Vector<Object>> data = new Vector<>();
            Vector<String> columnNames = new Vector<>();
            columnNames.add("Reservation ID");
            columnNames.add("Guest Name");
            columnNames.add("Room Number");
            columnNames.add("Contact Number");
            columnNames.add("Reservation Date");

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("reservation_id"));
                row.add(rs.getString("guest_name"));
                row.add(rs.getInt("room_number"));
                row.add(rs.getString("contact_number"));
                row.add(rs.getTimestamp("reservation_date").toString());
                data.add(row);
            }

            JTable table = new JTable(data, columnNames);
            JScrollPane scrollPane = new JScrollPane(table);
            JOptionPane.showMessageDialog(null, scrollPane, "View Reservations", JOptionPane.INFORMATION_MESSAGE);

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void updateReservation(int reservationId, String newGuestName, int newRoomNumber, String newContactNumber) {
        String sql = "UPDATE reservations SET guest_name = ?, room_number = ?, contact_number = ? " +
                "WHERE reservation_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, newGuestName);
            stmt.setInt(2, newRoomNumber);
            stmt.setString(3, newContactNumber);
            stmt.setInt(4, reservationId);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Reservation updated successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Update failed. Reservation not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void deleteReservation(int reservationId) {
        String sql = "DELETE FROM reservations WHERE reservation_id = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            int affectedRows = stmt.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(null, "Reservation deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(null, "Deletion failed. Reservation not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void getRoomNumber(int reservationId, String guestName) {
        String sql = "SELECT room_number FROM reservations WHERE reservation_id = ? AND guest_name = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, reservationId);
            stmt.setString(2, guestName);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                int roomNumber = rs.getInt("room_number");
                JOptionPane.showMessageDialog(null, "Room Number: " + roomNumber);
            } else {
                JOptionPane.showMessageDialog(null, "Reservation not found for given ID and guest name.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + e.getMessage());
        }
    }

    private void exitSystem() {
        int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);

        if (option == JOptionPane.YES_OPTION) {
            try {
                connection.close();
                System.exit(0);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}